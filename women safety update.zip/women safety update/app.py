from flask import (
    Flask,
    render_template,
    request,
    jsonify,
    redirect,
    url_for,
    session,
)

app = Flask(__name__)
app.secret_key = "dev-secret-key-change-me"

# In-memory user storage: email -> user dict
USERS = {}


def get_current_user():
    email = session.get("user_email")
    if not email:
        return None
    return USERS.get(email)


@app.route("/", methods=["GET", "POST"])
def login():
    error = None
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")

        user = USERS.get(email)
        if user and user.get("password") == password:
            session["user_email"] = email
            return redirect(url_for("dashboard"))
        else:
            error = "Invalid email or password."

    # If already logged in, go straight to dashboard
    if get_current_user():
        return redirect(url_for("dashboard"))

    return render_template("login.html", error=error)


@app.route("/register", methods=["GET", "POST"])
def register():
    error = None
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        parent_phone = request.form.get("parent_phone", "").strip()
        relative_phone = request.form.get("relative_phone", "").strip()

        if not all([name, email, password, parent_phone, relative_phone]):
            error = "All fields are required."
        elif email in USERS:
            error = "Email already registered. Please login."
        else:
            USERS[email] = {
                "name": name,
                "email": email,
                "password": password,
                "parent_phone": parent_phone,
                "relative_phone": relative_phone,
            }
            return redirect(url_for("login"))

    return render_template("register.html", error=error)


@app.route("/dashboard")
def dashboard():
    user = get_current_user()
    if not user:
        return redirect(url_for("login"))

    return render_template("dashboard.html", user=user)


@app.route("/logout")
def logout():
    session.pop("user_email", None)
    return redirect(url_for("login"))


@app.route("/sos", methods=["POST"])
def sos():
    user = get_current_user()

    data = request.get_json(silent=True) or {}
    lat = data.get("latitude")
    lng = data.get("longitude")
    ts = data.get("timestamp")

    print("=== SOS RECEIVED ===")
    if user:
        print(f"User       : {user.get('name')} ({user.get('email')})")
        print(f"Parent Ph. : {user.get('parent_phone')}")
        print(f"Relative Ph: {user.get('relative_phone')}")
    print(f"Latitude   : {lat}")
    print(f"Longitude  : {lng}")
    print(f"Timestamp  : {ts}")
    print("====================")

    return jsonify({"status": "ok", "message": "SOS received"}), 200


@app.route("/save_contacts", methods=["POST"])
def save_contacts():
    user = get_current_user()
    if not user:
        return jsonify({"error": "Not logged in"}), 401

    payload = request.get_json(silent=True) or {}
    parent_phone = payload.get("parent_phone", "").strip()
    relative_phone = payload.get("relative_phone", "").strip()

    if not parent_phone or not relative_phone:
        return jsonify({"error": "Both phone numbers are required."}), 400

    user["parent_phone"] = parent_phone
    user["relative_phone"] = relative_phone

    return jsonify(
        {
            "status": "ok",
            "parent_phone": parent_phone,
            "relative_phone": relative_phone,
        }
    )


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)