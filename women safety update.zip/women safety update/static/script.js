// Global state
let lastLatitude = null;
let lastLongitude = null;
let sosActive = false;
let mediaStream = null;
let unsafeStayTimer = null;

// Predefined unsafe areas (latitude, longitude, name)
const unsafeAreas = [
  { name: "Unsafe Zone 1", lat: 12.9716, lng: 77.5946 },
  { name: "Unsafe Zone 2", lat: 13.0827, lng: 80.2707 },
];

// Emergency contacts provided from backend on dashboard page
const EMERGENCY_CONTACT =
  (window && window.EMERGENCY_CONTACT) || {
    parentPhone: "",
    relativePhone: "",
  };

document.addEventListener("DOMContentLoaded", () => {
  const sosButton = document.getElementById("sosButton");
  if (!sosButton) {
    // Script is only fully used on dashboard; silently exit on other pages
    return;
  }

  sosButton.addEventListener("click", sendSOS);

  const contactForm = document.getElementById("contactForm");
  if (contactForm) {
    contactForm.addEventListener("submit", onSaveContacts);
  }

  getLocation(); // Start live location tracking
  detectShake(); // Enable shake detection
  startVoiceDetection(); // Enable voice activation
});

/* ================================
 *  CORE SOS LOGIC
 * ================================ */

async function sendSOS() {
  const statusEl = document.getElementById("statusMessage");
  if (!statusEl) return;

  statusEl.textContent = "Preparing SOS... getting location.";

  // Ensure we have location before sending SOS
  if (lastLatitude == null || lastLongitude == null) {
    try {
      const position = await getCurrentPositionPromise();
      updateLocation(position.coords.latitude, position.coords.longitude);
    } catch (err) {
      console.error("Error getting location for SOS:", err);
      statusEl.textContent = "Unable to get location. SOS not sent.";
      return;
    }
  }

  sosActive = true;
  statusEl.textContent =
    "SOS ACTIVE! Sending alert and starting safety measures...";

  playAlarm();
  startCamera();
  sendSOSRequestToServer();
  sendEmergencyMessage();
}

/* ================================
 *  LOCATION HANDLING
 * ================================ */

function getLocation() {
  if (!navigator.geolocation) {
    console.warn("Geolocation not supported.");
    const statusEl = document.getElementById("statusMessage");
    if (statusEl) {
      statusEl.textContent = "Geolocation not supported by this browser.";
    }
    return;
  }

  // Watch position for live tracking
  navigator.geolocation.watchPosition(
    (position) => {
      const { latitude, longitude } = position.coords;
      updateLocation(latitude, longitude);
    },
    (error) => {
      console.error("Error in watchPosition:", error);
      const statusEl = document.getElementById("statusMessage");
      if (statusEl) {
        statusEl.textContent = "Unable to get live location.";
      }
    },
    {
      enableHighAccuracy: true,
      maximumAge: 5000,
      timeout: 10000,
    }
  );
}

function getCurrentPositionPromise() {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new Error("Geolocation not supported"));
      return;
    }

    navigator.geolocation.getCurrentPosition(resolve, reject, {
      enableHighAccuracy: true,
      timeout: 10000,
    });
  });
}

function updateLocation(latitude, longitude) {
  lastLatitude = latitude;
  lastLongitude = longitude;

  const latEl = document.getElementById("latValue");
  const lngEl = document.getElementById("lngValue");
  const statusEl = document.getElementById("statusMessage");

  if (latEl) latEl.textContent = latitude.toFixed(6);
  if (lngEl) lngEl.textContent = longitude.toFixed(6);
  if (statusEl) {
    statusEl.textContent = sosActive
      ? "SOS ACTIVE - Tracking your live location..."
      : "Live location updated.";
  }

  updateMap(latitude, longitude);
  checkUnsafeArea(latitude, longitude);
}

/* ================================
 *  MAP HANDLING
 * ================================ */

function updateMap(latitude, longitude) {
  const mapFrame = document.getElementById("mapFrame");
  if (!mapFrame) return;
  const url = `https://www.google.com/maps?q=${latitude},${longitude}&z=16&output=embed`;
  mapFrame.src = url;
}

/* ================================
 *  SHAKE DETECTION
 * ================================ */

function detectShake() {
  if (!window.DeviceMotionEvent) {
    console.warn("DeviceMotionEvent not supported.");
    return;
  }

  let lastShakeTime = 0;
  const SHAKE_THRESHOLD = 15; // m/s^2
  const SHAKE_INTERVAL = 1500; // ms

  window.addEventListener("devicemotion", (event) => {
    const acc = event.accelerationIncludingGravity;
    if (!acc) return;

    const accMagnitude = Math.sqrt(
      (acc.x || 0) * (acc.x || 0) +
        (acc.y || 0) * (acc.y || 0) +
        (acc.z || 0) * (acc.z || 0)
    );

    if (accMagnitude > SHAKE_THRESHOLD) {
      const now = Date.now();
      if (now - lastShakeTime > SHAKE_INTERVAL) {
        lastShakeTime = now;
        const statusEl = document.getElementById("statusMessage");
        if (statusEl) {
          statusEl.textContent =
            "Strong shaking detected! Triggering SOS...";
        }
        sendSOS();
      }
    }
  });
}

/* ================================
 *  VOICE ACTIVATION
 * ================================ */

function startVoiceDetection() {
  const SpeechRecognition =
    window.SpeechRecognition || window.webkitSpeechRecognition;

  if (!SpeechRecognition) {
    console.warn("Web Speech API not supported.");
    return;
  }

  const recognition = new SpeechRecognition();
  recognition.continuous = true;
  recognition.interimResults = false;
  recognition.lang = "en-US";

  recognition.onresult = (event) => {
    const lastResult = event.results[event.results.length - 1];
    const transcript = lastResult[0].transcript.toLowerCase().trim();
    console.log("Voice detected:", transcript);

    if (
      transcript.includes("help") ||
      transcript.includes("help me") ||
      transcript.includes("danger")
    ) {
      const statusEl = document.getElementById("statusMessage");
      if (statusEl) {
        statusEl.textContent =
          'Voice command "' + transcript + '" detected. Triggering SOS...';
      }
      sendSOS();
    }
  };

  recognition.onerror = (event) => {
    console.warn("Speech recognition error:", event.error);
  };

  recognition.onend = () => {
    try {
      recognition.start();
    } catch (e) {
      // Ignore restart errors.
    }
  };

  try {
    recognition.start();
  } catch (e) {
    console.warn("Speech recognition start failed:", e);
  }
}

/* ================================
 *  CAMERA PREVIEW
 * ================================ */

async function startCamera() {
  const videoEl = document.getElementById("cameraPreview");
  if (!videoEl) return;

  try {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      console.warn("getUserMedia not supported.");
      return;
    }

    if (!mediaStream) {
      mediaStream = await navigator.mediaDevices.getUserMedia({
        video: true,
        audio: false,
      });
      videoEl.srcObject = mediaStream;
    }
  } catch (err) {
    console.error("Error starting camera preview:", err);
    const statusEl = document.getElementById("statusMessage");
    if (statusEl) {
      statusEl.textContent =
        "Could not start camera preview (permission denied?).";
    }
  }
}

/* ================================
 *  LOUD ALARM
 * ================================ */

function playAlarm() {
  const alarm = document.getElementById("alarmSound");
  if (!alarm) return;

  alarm
    .play()
    .then(() => {
      console.log("Alarm started.");
    })
    .catch((err) => {
      console.warn("Unable to play alarm automatically:", err);
    });
}

/* ================================
 *  BACKEND SOS API
 * ================================ */

function sendSOSRequestToServer() {
  if (lastLatitude == null || lastLongitude == null) return;

  fetch("/sos", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      latitude: lastLatitude,
      longitude: lastLongitude,
      timestamp: new Date().toISOString(),
    }),
  })
    .then((res) => res.json())
    .then((data) => {
      console.log("SOS sent to backend:", data);
      const statusEl = document.getElementById("statusMessage");
      if (statusEl) {
        statusEl.textContent = "SOS has been sent. Help is being notified.";
      }
    })
    .catch((err) => {
      console.error("Error sending SOS to backend:", err);
      const statusEl = document.getElementById("statusMessage");
      if (statusEl) {
        statusEl.textContent = "Error sending SOS to server.";
      }
    });
}

/* ================================
 *  UNSAFE AREA DETECTION
 * ================================ */

function checkUnsafeArea(currentLat, currentLng) {
  const unsafeMsgEl = document.getElementById("unsafeAreaMessage");
  if (!unsafeMsgEl) return;

  unsafeMsgEl.textContent = "";

  let closestArea = null;
  let closestDistance = Infinity;

  unsafeAreas.forEach((area) => {
    const distance = getDistanceMeters(
      currentLat,
      currentLng,
      area.lat,
      area.lng
    );
    if (distance < closestDistance) {
      closestDistance = distance;
      closestArea = area;
    }
  });

  const THRESHOLD_METERS = 500; // within 500m considered unsafe
  if (closestArea && closestDistance <= THRESHOLD_METERS) {
    unsafeMsgEl.textContent =
      "⚠ Unsafe Area Detected. Please stay alert.";

    // If user stays in unsafe area for more than X seconds, auto trigger SOS
    if (!unsafeStayTimer && !sosActive) {
      unsafeStayTimer = setTimeout(() => {
        const statusEl = document.getElementById("statusMessage");
        if (statusEl) {
          statusEl.textContent =
            "You are staying in an unsafe area. Automatically triggering SOS.";
        }
        sendSOS();
      }, 15000); // 15 seconds stay
    }
  } else {
    unsafeMsgEl.textContent = "";
    if (unsafeStayTimer) {
      clearTimeout(unsafeStayTimer);
      unsafeStayTimer = null;
    }
  }
}

// Haversine distance in meters
function getDistanceMeters(lat1, lng1, lat2, lng2) {
  const R = 6371e3; // Earth radius in meters
  const toRad = (deg) => (deg * Math.PI) / 180;

  const phi1 = toRad(lat1);
  const phi2 = toRad(lat2);
  const dPhi = toRad(lat2 - lat1);
  const dLambda = toRad(lng2 - lng1);

  const a =
    Math.sin(dPhi / 2) * Math.sin(dPhi / 2) +
    Math.cos(phi1) *
      Math.cos(phi2) *
      Math.sin(dLambda / 2) *
      Math.sin(dLambda / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  return R * c;
}

/* ================================
 *  EMERGENCY MESSAGE TO PARENTS
 * ================================ */

function sendEmergencyMessage() {
  if (lastLatitude == null || lastLongitude == null) {
    console.warn("No location for emergency message.");
    return;
  }

  if (!EMERGENCY_CONTACT.parentPhone) {
    console.warn("Parent phone not configured.");
    const contactStatus = document.getElementById("contactStatus");
    if (contactStatus) {
      contactStatus.textContent =
        "Parent phone not set. Please save emergency contacts first.";
    }
    return;
  }

  const mapLink = `https://maps.google.com/?q=${lastLatitude},${lastLongitude}`;
  const message = `🚨 Emergency! I may be in danger. My location: ${mapLink}`;
  const encodedMessage = encodeURIComponent(message);

  const parentUrl = `https://wa.me/${EMERGENCY_CONTACT.parentPhone}?text=${encodedMessage}`;

  // Open WhatsApp chat with parent in new tab
  window.open(parentUrl, "_blank");

  // Optionally also open for relative if configured
  if (EMERGENCY_CONTACT.relativePhone) {
    const relativeUrl = `https://wa.me/${EMERGENCY_CONTACT.relativePhone}?text=${encodedMessage}`;
    window.open(relativeUrl, "_blank");
  }
}

/* ================================
 *  SAVE CONTACTS TO BACKEND
 * ================================ */

function onSaveContacts(event) {
  event.preventDefault();

  const parentInput = document.getElementById("parent_phone_input");
  const relativeInput = document.getElementById("relative_phone_input");
  const statusEl = document.getElementById("contactStatus");

  if (!parentInput || !relativeInput) return;

  const parent_phone = parentInput.value.trim();
  const relative_phone = relativeInput.value.trim();

  if (!parent_phone || !relative_phone) {
    if (statusEl) {
      statusEl.textContent = "Both phone numbers are required.";
    }
    return;
  }

  fetch("/save_contacts", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ parent_phone, relative_phone }),
  })
    .then((res) => res.json())
    .then((data) => {
      if (data.error) {
        if (statusEl) statusEl.textContent = data.error;
        return;
      }

      EMERGENCY_CONTACT.parentPhone = data.parent_phone;
      EMERGENCY_CONTACT.relativePhone = data.relative_phone;

      if (statusEl) {
        statusEl.textContent = "Contacts saved successfully.";
      }
    })
    .catch((err) => {
      console.error("Error saving contacts:", err);
      if (statusEl) {
        statusEl.textContent = "Failed to save contacts.";
      }
    });
}
